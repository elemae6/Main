package com.example.firstproject.ioc;

public class Pork extends Ingredient {
    public Pork(String name) {
        super(name);
    }
}
