package com.example.firstproject.ioc;

public class Beef extends Ingredient {
    public Beef(String name) {
        super(name);
    }
}
