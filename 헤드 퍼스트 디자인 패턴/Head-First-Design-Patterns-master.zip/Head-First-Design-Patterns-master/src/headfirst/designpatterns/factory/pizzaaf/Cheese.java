package headfirst.designpatterns.factory.pizzaaf;

public interface Cheese {
	public String toString();
}
